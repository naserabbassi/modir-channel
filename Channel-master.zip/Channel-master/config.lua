bot_token = ""
send_api = "https://api.telegram.org/bot"..bot_token
bot_version = "2.5"
sudo_id = 212400472
